package easterRaces;

import easterRaces.core.ControllerImpl;
import easterRaces.core.EngineImpl;
import easterRaces.core.interfaces.Controller;
import easterRaces.entities.cars.Car;
import easterRaces.entities.drivers.Driver;
import easterRaces.entities.racers.Race;
import easterRaces.io.ConsoleReader;
import easterRaces.io.ConsoleWriter;
import easterRaces.repositories.interfaces.Data;
import easterRaces.repositories.interfaces.Repository;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        Repository<Car> motorcycleRepository = new Data<Car>();//
        Repository<Race> raceRepository = new Data<Race>();//
        Repository<Driver> riderRepository = new Data<Driver>();//
        Controller controller = new ControllerImpl(riderRepository,motorcycleRepository,raceRepository); // TODO: new ControllerImpl(riderRepository, motorcycleRepository, raceRepository);
        ConsoleReader reader = new ConsoleReader();
        ConsoleWriter writer = new ConsoleWriter();
        EngineImpl engine = new EngineImpl(reader, writer, controller);
        engine.run();
    }
}
