package easterRaces.repositories.interfaces;

import easterRaces.entities.drivers.Driver;
public interface DriverRepository{

}
