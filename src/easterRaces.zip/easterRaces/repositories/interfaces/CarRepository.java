package easterRaces.repositories.interfaces;

public interface CarRepository {
}
