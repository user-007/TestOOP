package easterRaces.repositories.interfaces;

public interface RaceRepository{

}
